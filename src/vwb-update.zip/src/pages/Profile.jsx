import { useAuth } from '../context/AuthContext'

export default function Profile() {
  const { user, profile, signOut } = useAuth()

  const displayName = profile?.display_name || 'Neighbor'

  return (
    <div className="profile-page">
      <div className="profile-header-section">
        <div className="avatar-placeholder">
          {displayName.charAt(0).toUpperCase()}
        </div>
        <h1>{displayName}</h1>
        {profile?.is_hope_ambassador && (
          <span className="ambassador-badge">Hope Ambassador</span>
        )}
        <p className="profile-email">{user?.email}</p>
      </div>

      <div className="profile-details">
        <div className="detail-row">
          <span className="detail-label">Zip code</span>
          <span className="detail-value">{profile?.zip_code || 'Not set'}</span>
        </div>
        <div className="detail-row">
          <span className="detail-label">Neighborhood</span>
          <span className="detail-value">{profile?.neighborhood || 'Not set'}</span>
        </div>
        <div className="detail-row">
          <span className="detail-label">Skills</span>
          <span className="detail-value">
            {profile?.skills?.length > 0
              ? profile.skills.join(', ')
              : 'None yet'}
          </span>
        </div>
        <div className="detail-row">
          <span className="detail-label">Tasks completed</span>
          <span className="detail-value">{profile?.tasks_completed || 0}</span>
        </div>
      </div>

      <button
        className="btn btn-outline btn-full"
        style={{ marginTop: '2rem' }}
        onClick={signOut}
      >
        Sign out
      </button>
    </div>
  )
}
